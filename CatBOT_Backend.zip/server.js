const express = require("express");
const cors = require("cors");
const axios = require("axios");

const app = express();
app.use(cors());
app.use(express.json());

const HF_API_URL = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-small";
const HEADERS = { "Authorization": "Bearer YOUR_HUGGINGFACE_API_KEY" };

app.post("/chat", async (req, res) => {
    const userMessage = req.body.message;
    try {
        const response = await axios.post(HF_API_URL, { inputs: userMessage }, { headers: HEADERS });
        const botReply = response.data[0]?.generated_text || "Sorry, I couldn't process that.";
        res.json({ user: userMessage, bot: botReply });
    } catch (error) {
        res.status(500).json({ error: "API error" });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
